// TaNow Online - Static Site
// This file exists for deployment compatibility only
// The actual app is served from /public folder
console.log('TaNow Online - IPTV Directory');
