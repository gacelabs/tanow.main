// TaNow Online - Static Site Placeholder
// Actual content is in /public/index.html
function App() { return null; }
export default App;
